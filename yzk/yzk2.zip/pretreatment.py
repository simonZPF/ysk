import pandas as pd
import re
data = pd.read_csv('风险标签数据(2).csv', encoding='GB18030',engine='python')
content = data['内容']
pattern = re.compile(r'<(.*?)>')
string = ''
with open("predata.txt", 'w',encoding='utf-8') as f:
    for i in content:
        string += re.sub(pattern, "", i).replace("\n", "").replace(" ","").replace('　　',"") + "\n"
    f.write(string)
